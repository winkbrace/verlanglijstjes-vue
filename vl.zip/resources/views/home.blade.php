@extends('layout')

@section('content')
    <member-list></member-list>
    <br>
@endsection
