<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Verlanglijstjes</title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Scripts -->
    <script>
        window.Laravel = { "csrfToken": "<?php echo csrf_token(); ?>" };
    </script>
</head>
<body>
    <header>
        <h1>Verlanglijstjes</h1>
        <a class="awesome" href="<?php echo e(url('/')); ?>"><i class="fa fa-gift"></i></a>

        <ul class="head-nav">
            <?php if(Auth::guest()): ?>
                <li class="btn btn-login">
                    <span>Inloggen</span>
                    <a class="btn-main green" href="<?php echo e(url('/login')); ?>"><i class="fa fa-user"></i></a>
                </li>
            <?php else: ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </header>

    <section class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </section>

    <footer>
        <!--Bas if homepage do not show-->
        <div class="btn-home"> <span>Home</span>
            <a class="btn btn-main green" href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i></a>
        </div>

        <!--Bas laat deze knop staan eerst wil ik testen wat we hier doen -->
        <div class="btn-add"><span>Cadeaux</span>
            <a class="btn btn-main pink"><i class="fa fa-plus"></i></a>
        </div>
    </footer>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
