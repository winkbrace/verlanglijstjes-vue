<?php $__env->startSection('content'); ?>
    <div class="row form-container">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e($target); ?>">
            <?php echo e(csrf_field()); ?>


            <div class="form-group<?php echo e($errors->has('wish') ? ' has-error' : ''); ?>">
                <label for="wish" class="col-md-4 control-label">Cadeau</label>

                <div class="col-md-6">
                    <input id="wish" type="text" class="form-control" name="wish" value="<?php echo e(old('wish', isset($wish) ? $wish->description : '')); ?>" required autofocus>

                    <?php if($errors->has('wish')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('wish')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group<?php echo e($errors->has('link') ? ' has-error' : ''); ?>">
                <label for="link" class="col-md-4 control-label">Link</label>

                <div class="col-md-6">
                    <input id="link" type="url" class="form-control" name="link" value="<?php echo e(old('link', isset($wish) ? $wish->link : '')); ?>">

                    <?php if($errors->has('link')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('link')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-8 col-md-offset-4">
                    <button type="submit" class="btn btn-primary"><?php echo e($buttonText); ?></button>
                    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default">Annuleren</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>