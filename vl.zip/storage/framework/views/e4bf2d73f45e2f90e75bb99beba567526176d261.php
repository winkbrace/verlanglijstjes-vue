<?php $__env->startSection('content'); ?>
    <wish-list name="<?php echo e($name); ?>" current-user-id="<?php echo e(Auth::user() ? Auth::user()->id : null); ?>"></wish-list>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>