<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Verlanglijstje<?php echo e($name ? ' van ' . $name : 's'); ?></title>

    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="/css/animate.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

    <!-- Scripts -->
    <script>
        window.Laravel = { "csrfToken": "<?php echo csrf_token(); ?>" };
    </script>
</head>
<body id="container">

	<wishlist-header username="<?php echo e($username); ?>" list-owner="<?php echo e(isset($name) ? $name : ''); ?>"></wishlist-header>

	<section class="content">
        <?php echo $__env->yieldContent('content'); ?>
	</section>

    <wishlist-footer
        username="<?php echo e($username); ?>"
        :at-home-page="<?php echo e(Request::getPathInfo() == '/' ? 'true' : 'false'); ?>"
        list-owner="<?php echo e(isset($name) ? $name : ''); ?>"
    />

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
